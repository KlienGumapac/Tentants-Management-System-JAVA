/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MAIN;

import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.application.Platform.exit;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.NO_OPTION;
import static javax.swing.JOptionPane.YES_OPTION;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author chris
 */
public class Menu1 extends javax.swing.JPanel {

    private Component rootPane;

    /**
     * Creates new form NewJPanel
     */
    public Menu1() {
        initComponents();
        VIEW_USER_TBL.fixTable(jScrollPane1);
        USER_UID_TBL.fixTable(jScrollPane2);
        Fetch_USER_UID();
        Fetch_USER_IDENTITY_THAT_USED_THE_UID();
        
    }
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    Statement stmt = null;

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelRounded2 = new ROUNDEDPANEL.PanelRounded();
        form1 = new compo.Form();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        VIEW_USER_TBL = new tabledark.TableDark();
        jScrollPane2 = new javax.swing.JScrollPane();
        USER_UID_TBL = new tabledark.TableDark();
        panelRounded1 = new ROUNDEDPANEL.PanelRounded();
        jLabel3 = new javax.swing.JLabel();
        USER_CREATION = new textfield.TextField();
        ADDUSER = new com.raven.swing.Button();
        UPDATEUSER = new com.raven.swing.Button();
        DELETEUSER = new com.raven.swing.Button();
        SEARCH_CREATED_USER_UID = new textfield.TextField();
        SEARCH_BTN_FOR_CREATED_ID = new com.raven.swing.Button();
        panelRounded3 = new ROUNDEDPANEL.PanelRounded();
        panelRounded4 = new ROUNDEDPANEL.PanelRounded();
        jLabel1 = new javax.swing.JLabel();
        panelRounded5 = new ROUNDEDPANEL.PanelRounded();
        SEARCH_USER_UID = new textfield.TextField();
        button1 = new com.raven.swing.Button();
        button2 = new com.raven.swing.Button();
        USER_UID = new textfield.TextField();
        USER_FULLNAME = new textfield.TextField();
        USER_AGE = new textfield.TextField();
        USER_GENDER = new textfield.TextField();
        panelRounded6 = new ROUNDEDPANEL.PanelRounded();
        panelRounded7 = new ROUNDEDPANEL.PanelRounded();
        jLabel2 = new javax.swing.JLabel();

        javax.swing.GroupLayout panelRounded2Layout = new javax.swing.GroupLayout(panelRounded2);
        panelRounded2.setLayout(panelRounded2Layout);
        panelRounded2Layout.setHorizontalGroup(
            panelRounded2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        panelRounded2Layout.setVerticalGroup(
            panelRounded2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        form1.setPreferredSize(new java.awt.Dimension(877, 489));

        jPanel1.setBackground(new java.awt.Color(12, 12, 12));
        jPanel1.setPreferredSize(new java.awt.Dimension(1020, 660));

        VIEW_USER_TBL.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "USER-UID", "FULLNAME", "AGE", "GENDER"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        VIEW_USER_TBL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VIEW_USER_TBLMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(VIEW_USER_TBL);
        if (VIEW_USER_TBL.getColumnModel().getColumnCount() > 0) {
            VIEW_USER_TBL.getColumnModel().getColumn(0).setPreferredWidth(5);
            VIEW_USER_TBL.getColumnModel().getColumn(2).setPreferredWidth(5);
            VIEW_USER_TBL.getColumnModel().getColumn(3).setPreferredWidth(5);
        }

        USER_UID_TBL.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "USER-UID"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        USER_UID_TBL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                USER_UID_TBLMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(USER_UID_TBL);

        panelRounded1.setBackground(new java.awt.Color(255, 255, 255));
        panelRounded1.setRoundBottomLeft(25);
        panelRounded1.setRoundBottomRight(25);
        panelRounded1.setRoundTopLeft(25);
        panelRounded1.setRoundTopRight(25);

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(12, 12, 12));
        jLabel3.setText("CREATE USER UID");

        USER_CREATION.setLabelText("CREATE ID");

        ADDUSER.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        ADDUSER.setText("ADD");
        ADDUSER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ADDUSERActionPerformed(evt);
            }
        });

        UPDATEUSER.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        UPDATEUSER.setText("UPDATE");

        DELETEUSER.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        DELETEUSER.setText("DELETE");

        SEARCH_CREATED_USER_UID.setLabelText("SEARCH");

        SEARCH_BTN_FOR_CREATED_ID.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        SEARCH_BTN_FOR_CREATED_ID.setText("ADD");
        SEARCH_BTN_FOR_CREATED_ID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEARCH_BTN_FOR_CREATED_IDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelRounded1Layout = new javax.swing.GroupLayout(panelRounded1);
        panelRounded1.setLayout(panelRounded1Layout);
        panelRounded1Layout.setHorizontalGroup(
            panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRounded1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel3)
                .addContainerGap(34, Short.MAX_VALUE))
            .addGroup(panelRounded1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(UPDATEUSER, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(USER_CREATION, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ADDUSER, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DELETEUSER, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SEARCH_CREATED_USER_UID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SEARCH_BTN_FOR_CREATED_ID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panelRounded1Layout.setVerticalGroup(
            panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRounded1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(SEARCH_CREATED_USER_UID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SEARCH_BTN_FOR_CREATED_ID, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(USER_CREATION, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ADDUSER, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(UPDATEUSER, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DELETEUSER, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
        );

        panelRounded3.setBackground(new java.awt.Color(234, 199, 199));
        panelRounded3.setRoundBottomRight(25);
        panelRounded3.setRoundTopLeft(25);

        panelRounded4.setBackground(new java.awt.Color(12, 12, 12));
        panelRounded4.setRoundBottomRight(25);
        panelRounded4.setRoundTopLeft(25);

        javax.swing.GroupLayout panelRounded4Layout = new javax.swing.GroupLayout(panelRounded4);
        panelRounded4.setLayout(panelRounded4Layout);
        panelRounded4Layout.setHorizontalGroup(
            panelRounded4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 142, Short.MAX_VALUE)
        );
        panelRounded4Layout.setVerticalGroup(
            panelRounded4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 31, Short.MAX_VALUE)
        );

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(12, 12, 12));
        jLabel1.setText("USERS");

        javax.swing.GroupLayout panelRounded3Layout = new javax.swing.GroupLayout(panelRounded3);
        panelRounded3.setLayout(panelRounded3Layout);
        panelRounded3Layout.setHorizontalGroup(
            panelRounded3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRounded3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelRounded4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelRounded3Layout.setVerticalGroup(
            panelRounded3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRounded3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelRounded3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(panelRounded4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        panelRounded5.setBackground(new java.awt.Color(255, 255, 255));
        panelRounded5.setRoundBottomLeft(25);
        panelRounded5.setRoundBottomRight(25);
        panelRounded5.setRoundTopLeft(25);
        panelRounded5.setRoundTopRight(25);

        SEARCH_USER_UID.setLabelText("SEARCH ID");
        SEARCH_USER_UID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                SEARCH_USER_UIDKeyTyped(evt);
            }
        });

        button1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        button1.setText("SEARCH");
        button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button1ActionPerformed(evt);
            }
        });

        button2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        button2.setText("CLEAR");
        button2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });

        USER_UID.setEditable(false);
        USER_UID.setBackground(new java.awt.Color(255, 255, 255));
        USER_UID.setLabelText("SEARCH ID");

        USER_FULLNAME.setEditable(false);
        USER_FULLNAME.setBackground(new java.awt.Color(255, 255, 255));
        USER_FULLNAME.setLabelText("FULLNAME");

        USER_AGE.setEditable(false);
        USER_AGE.setBackground(new java.awt.Color(255, 255, 255));
        USER_AGE.setLabelText("AGE");

        USER_GENDER.setEditable(false);
        USER_GENDER.setBackground(new java.awt.Color(255, 255, 255));
        USER_GENDER.setLabelText("GENDER");

        javax.swing.GroupLayout panelRounded5Layout = new javax.swing.GroupLayout(panelRounded5);
        panelRounded5.setLayout(panelRounded5Layout);
        panelRounded5Layout.setHorizontalGroup(
            panelRounded5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRounded5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelRounded5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelRounded5Layout.createSequentialGroup()
                        .addComponent(USER_UID, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(USER_FULLNAME, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelRounded5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(SEARCH_USER_UID, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelRounded5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(button1, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)
                    .addComponent(USER_AGE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(panelRounded5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(button2, javax.swing.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)
                    .addComponent(USER_GENDER, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(31, 31, 31))
        );
        panelRounded5Layout.setVerticalGroup(
            panelRounded5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRounded5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelRounded5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SEARCH_USER_UID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(button1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(button2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(panelRounded5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(USER_UID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(USER_FULLNAME, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(USER_AGE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(USER_GENDER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(50, Short.MAX_VALUE))
        );

        panelRounded6.setBackground(new java.awt.Color(0, 129, 201));
        panelRounded6.setRoundBottomRight(25);
        panelRounded6.setRoundTopLeft(25);

        panelRounded7.setBackground(new java.awt.Color(12, 12, 12));
        panelRounded7.setRoundBottomRight(25);
        panelRounded7.setRoundTopLeft(25);

        javax.swing.GroupLayout panelRounded7Layout = new javax.swing.GroupLayout(panelRounded7);
        panelRounded7.setLayout(panelRounded7Layout);
        panelRounded7Layout.setHorizontalGroup(
            panelRounded7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 142, Short.MAX_VALUE)
        );
        panelRounded7Layout.setVerticalGroup(
            panelRounded7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 31, Short.MAX_VALUE)
        );

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 18)); // NOI18N
        jLabel2.setText("CREATE ID");

        javax.swing.GroupLayout panelRounded6Layout = new javax.swing.GroupLayout(panelRounded6);
        panelRounded6.setLayout(panelRounded6Layout);
        panelRounded6Layout.setHorizontalGroup(
            panelRounded6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRounded6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelRounded7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addContainerGap(214, Short.MAX_VALUE))
        );
        panelRounded6Layout.setVerticalGroup(
            panelRounded6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRounded6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelRounded6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(panelRounded7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 789, Short.MAX_VALUE)
                    .addComponent(panelRounded3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelRounded5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelRounded1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(panelRounded6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panelRounded3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelRounded6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelRounded1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 394, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelRounded5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );

        javax.swing.GroupLayout form1Layout = new javax.swing.GroupLayout(form1);
        form1.setLayout(form1Layout);
        form1Layout.setHorizontalGroup(
            form1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1284, Short.MAX_VALUE)
        );
        form1Layout.setVerticalGroup(
            form1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(form1Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(form1, javax.swing.GroupLayout.PREFERRED_SIZE, 1284, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(form1, javax.swing.GroupLayout.PREFERRED_SIZE, 660, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void ADDUSERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ADDUSERActionPerformed
        // TODO add your handling code here:
        CREATE_USER_UID();Fetch_USER_UID();
    }//GEN-LAST:event_ADDUSERActionPerformed

    private void SEARCH_USER_UIDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SEARCH_USER_UIDKeyTyped
        
        
    }//GEN-LAST:event_SEARCH_USER_UIDKeyTyped

    private void button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button1ActionPerformed
        SEARCH_USER();
        
    }//GEN-LAST:event_button1ActionPerformed

    private void button2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button2ActionPerformed
        CLEAR_SEARCHED_USER();
    }//GEN-LAST:event_button2ActionPerformed

    private void VIEW_USER_TBLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VIEW_USER_TBLMouseClicked

       int i = VIEW_USER_TBL.getSelectedRow();
        TableModel model = VIEW_USER_TBL.getModel();
        USER_UID.setText(model.getValueAt(i, 0).toString());
        USER_FULLNAME.setText(model.getValueAt(i, 1).toString());
        USER_AGE.setText(model.getValueAt(i, 2).toString());
        USER_GENDER.setText(model.getValueAt(i, 3).toString());
        
    }//GEN-LAST:event_VIEW_USER_TBLMouseClicked

    private void USER_UID_TBLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_USER_UID_TBLMouseClicked
        int i = USER_UID_TBL.getSelectedRow();
        TableModel model = USER_UID_TBL.getModel();
        USER_CREATION.setText(model.getValueAt(i, 0).toString());
        
    }//GEN-LAST:event_USER_UID_TBLMouseClicked

    private void SEARCH_BTN_FOR_CREATED_IDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEARCH_BTN_FOR_CREATED_IDActionPerformed
        SEARCH_CREATED_USER_UID();
    }//GEN-LAST:event_SEARCH_BTN_FOR_CREATED_IDActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.raven.swing.Button ADDUSER;
    private com.raven.swing.Button DELETEUSER;
    private com.raven.swing.Button SEARCH_BTN_FOR_CREATED_ID;
    private textfield.TextField SEARCH_CREATED_USER_UID;
    private textfield.TextField SEARCH_USER_UID;
    private com.raven.swing.Button UPDATEUSER;
    private textfield.TextField USER_AGE;
    private textfield.TextField USER_CREATION;
    private textfield.TextField USER_FULLNAME;
    private textfield.TextField USER_GENDER;
    private textfield.TextField USER_UID;
    private tabledark.TableDark USER_UID_TBL;
    private tabledark.TableDark VIEW_USER_TBL;
    private com.raven.swing.Button button1;
    private com.raven.swing.Button button2;
    private compo.Form form1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private ROUNDEDPANEL.PanelRounded panelRounded1;
    private ROUNDEDPANEL.PanelRounded panelRounded2;
    private ROUNDEDPANEL.PanelRounded panelRounded3;
    private ROUNDEDPANEL.PanelRounded panelRounded4;
    private ROUNDEDPANEL.PanelRounded panelRounded5;
    private ROUNDEDPANEL.PanelRounded panelRounded6;
    private ROUNDEDPANEL.PanelRounded panelRounded7;
    // End of variables declaration//GEN-END:variables
    private void Fetch_USER_UID(){
        try {
            int q;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            pstmt = conn.prepareStatement("SELECT * FROM user_id_creation_tbl");
            rs = pstmt.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q=rss.getColumnCount();
            DefaultTableModel df= (DefaultTableModel)USER_UID_TBL.getModel();
            df.setRowCount(0);
            while(rs.next()){
            Vector v2 = new Vector();
            for(int a=1; a<=q;a++){
            v2.add(rs.getString("unique_id"));
            }
            df.addRow(v2);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    private void Fetch_USER_IDENTITY_THAT_USED_THE_UID(){
        try {
            int q;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            pstmt = conn.prepareStatement("SELECT * FROM user");
            rs = pstmt.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q=rss.getColumnCount();
            DefaultTableModel df= (DefaultTableModel)VIEW_USER_TBL.getModel();
            df.setRowCount(0);
            while(rs.next()){
            Vector v2 = new Vector();
            for(int a=1; a<=q;a++){
            v2.add(rs.getString("unique_id"));
            v2.add(rs.getString("full_name"));
            v2.add(rs.getString("age"));
            v2.add(rs.getString("gender"));
            }
            df.addRow(v2);
            
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    private void CREATE_USER_UID(){
        String createuser = USER_CREATION.getText().trim();
        if(!createuser.isEmpty()){
        try {
        // Open a connection to the database
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
        String sql = "SELECT * FROM user_id_creation_tbl WHERE unique_id = ?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, createuser);
        rs = pstmt.executeQuery();
   if (rs.next()) {
       JOptionPane.showMessageDialog(this,"DUPLICATE FOUND!!");
       
      // A record with the same email address already exists
      // Decide what to do (e.g., throw an exception)
   } else {
      // No record with the same email address exists, so insert a new record
        sql = "INSERT INTO user_id_creation_tbl (unique_id) VALUES (?)";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, createuser);
        pstmt.executeUpdate();
        JOptionPane.showMessageDialog(this,"SUCCESSFULLY ADDED.");
        DefaultTableModel model = (DefaultTableModel) USER_UID_TBL.getModel();
        Object[] row = new Object[4];
        row[0] = createuser;
        model.addRow(row);
        USER_CREATION.setText("");
       
   }
} catch (SQLException e) {
   // Handle any SQL errors
} finally {
   // Close the ResultSet, PreparedStatement, and Connection
   if (rs != null) {
       try {
           rs.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
   if (pstmt != null) {
       try {
           pstmt.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
   if (conn != null) {
       try {
           conn.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
}
        }else{
            JOptionPane.showMessageDialog(this,"FILL ALL THE BLANKS. ");
        }
    }
    
    private void UPDATE_USER_UID(){
        String createuser = USER_CREATION.getText().trim();
   
        if (!createuser.isEmpty()) {
            
        try {
            // Open a connection to the database
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            String sql = "SELECT * FROM user_id_creation_tbl WHERE unique_id =?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, createuser);
            rs = pstmt.executeQuery();

        if (rs.next()) {
            JOptionPane.showMessageDialog(this,"USER "+ createuser +" FOUND.");
            //
            //
        } else {
            JOptionPane.showMessageDialog(this,"USER UID NOT FOUND! TRY AGAIN.");
        }        
        } catch (SQLException e) {
        // Handle any SQL errors
        } finally {
        // Close the ResultSet, PreparedStatement, and Connection
        if (rs != null) {
        try {
           rs.close();
        } catch (SQLException ex) {
           Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
        if (pstmt != null) {
        try {
           pstmt.close();
        } catch (SQLException ex) {
           Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        if (conn != null) {
       try {
           conn.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
} 
            
        }else{
            JOptionPane.showMessageDialog(this,"FILL ALL THE BLANKS. ");
            
        }
    }
    
    private void UPDATE_USER_UID_UPDATE(){
            String createuser = USER_CREATION.getText().trim();
       if (!createuser.isEmpty()) { 
            try {
        //CHECKS IF THE TYPED CHARACTER EXIST IN user TABLE FROM DATABASE
        String SQL = "SELECT * FROM user WHERE unique_id =?";
        pstmt = conn.prepareStatement(SQL);
        pstmt.setString(1, createuser);
        rs = pstmt.executeQuery();
        if (rs.next()) {
            
            JOptionPane.showMessageDialog(this,"USER "+ createuser +" ALREADY OCCUPIED.");
            //CALL ANOTHER
        } else {
              
   }    
        
} catch (SQLException e) {
   // Handle any SQL errors
} finally {
   // Close the ResultSet, PreparedStatement, and Connection
   if (rs != null) {
       try {
           rs.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
   if (pstmt != null) {
       try {
           pstmt.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
   if (conn != null) {
       try {
           conn.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
} 
            
        }else{
            JOptionPane.showMessageDialog(this,"FILL ALL THE BLANKS.");
            
        }
    }
    
    private void UPDATE_USER_UID_MAIN_TBL(){
         String createuser = USER_CREATION.getText().trim();
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            String sqll = "UPDATE user SET WHERE unique_id='" + createuser + "'";
            stmt = conn.createStatement();
            stmt.execute(sqll);
            JOptionPane.showMessageDialog(this,"USER UID .");
        } catch (SQLException ex) {
            Logger.getLogger(Menu1.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    

    private void SEARCH_USER(){
        String suuid = SEARCH_USER_UID.getText();
        if(!suuid.isEmpty()){
        try {
            
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            String sql = "SELECT * FROM user WHERE unique_id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,SEARCH_USER_UID.getText());
            rs= pstmt.executeQuery();
            if(rs.next()){
                
                String uid = rs.getString("unique_id");USER_UID.setText(uid);
                String fulln = rs.getString("full_name");USER_FULLNAME.setText(fulln);
                String agee = rs.getString("age");USER_AGE.setText(agee);
                String gendr = rs.getString("gender");USER_GENDER.setText(gendr);
                SEARCH_USER_UID.setText("");
                              
            }else{
                JOptionPane.showMessageDialog(this,"INPUT A CORRECT USER-UID.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
        }
        }else{
            JOptionPane.showMessageDialog(this,"TEXTFIELD IS EMPTY.");
        }
    }
    
    private void SEARCH_CREATED_USER_UID(){
        String scuu = SEARCH_CREATED_USER_UID.getText();
        if(!scuu.isEmpty()){
        try {
            
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            String sql = "SELECT * FROM user_id_creation_tbl WHERE unique_id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,SEARCH_CREATED_USER_UID.getText());
            rs= pstmt.executeQuery();
            if(rs.next()){
                
                String uid = rs.getString("unique_id");USER_CREATION.setText(uid);
                SEARCH_CREATED_USER_UID.setText("");
                              
            }else{
                JOptionPane.showMessageDialog(this,"INPUT A CORRECT USER-UID.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
        }
        }else{
            JOptionPane.showMessageDialog(this,"TEXTFIELD IS EMPTY.");
        }
    }
    private void CLEAR_SEARCHED_USER(){
        USER_UID.setText("");
        USER_FULLNAME.setText("");
        USER_AGE.setText("");
        USER_GENDER.setText("");
    
    }
}
