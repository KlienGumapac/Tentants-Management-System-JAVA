/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MAIN;

import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.application.Platform.exit;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.YES_OPTION;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author chris
 */
public class MANAGETENANT extends javax.swing.JPanel {

    private Component rootPane;

    /**
     * Creates new form NewJPanel
     */
    public MANAGETENANT() {
        initComponents();
        MANAGETENANT_TBL.fixTable(jScrollPane1);
        SHOW_OCCUPANT_TBL.fixTable(jScrollPane2);
        SHOW_DATE_TIME();
        room_RATE();
        room_ID();
        DATABASE_TBL_STORE_TENANTS();
        
        FETCH_TENANT_INFO();
    }

    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    Statement stmt = null;
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        GENDER = new javax.swing.JLabel();
        CATEGORY_DBTN = new javax.swing.JLabel();
        MAX = new javax.swing.JLabel();
        MIN = new javax.swing.JLabel();
        TOTAL = new javax.swing.JLabel();
        DUEDATE = new javax.swing.JLabel();
        GETROOMCATEGORY = new javax.swing.JLabel();
        form1 = new compo.Form();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        MANAGETENANT_TBL = new tabledark.TableDark();
        panelRounded1 = new ROUNDEDPANEL.PanelRounded();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        FULLNAME = new textfield.TextField();
        AGE = new textfield.TextField();
        FEMALE = new radio_button.RadioButtonCustom();
        jLabel2 = new javax.swing.JLabel();
        MALE = new radio_button.RadioButtonCustom();
        PHONENUMBER = new textfield.TextField();
        ROOMCATEGORY = new combobox.Combobox();
        ADDRESS = new textfield.TextField();
        ADD = new com.raven.swing.Button();
        UPDATE = new com.raven.swing.Button();
        DISABLE_USER = new com.raven.swing.Button();
        SEARCHFULLNAME = new textfield.TextField();
        ROOMRATE = new textfield.TextField();
        DATE = new javax.swing.JLabel();
        DELETE1 = new com.raven.swing.Button();
        jScrollPane2 = new javax.swing.JScrollPane();
        SHOW_OCCUPANT_TBL = new tabledark.TableDark();

        DUEDATE.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        GETROOMCATEGORY.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        setPreferredSize(new java.awt.Dimension(1308, 778));

        form1.setPreferredSize(new java.awt.Dimension(1308, 778));

        jPanel1.setBackground(new java.awt.Color(12, 12, 12));
        jPanel1.setPreferredSize(new java.awt.Dimension(1020, 660));

        MANAGETENANT_TBL.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "FULLNAME", "AGE", "GENDER", "PHONE NUMBER", "ADDRESS", "ROOM CATEGORY", "ROOM RATE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        MANAGETENANT_TBL.getTableHeader().setReorderingAllowed(false);
        MANAGETENANT_TBL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MANAGETENANT_TBLMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(MANAGETENANT_TBL);
        if (MANAGETENANT_TBL.getColumnModel().getColumnCount() > 0) {
            MANAGETENANT_TBL.getColumnModel().getColumn(1).setPreferredWidth(12);
            MANAGETENANT_TBL.getColumnModel().getColumn(2).setPreferredWidth(12);
            MANAGETENANT_TBL.getColumnModel().getColumn(3).setPreferredWidth(12);
            MANAGETENANT_TBL.getColumnModel().getColumn(6).setPreferredWidth(12);
        }

        panelRounded1.setBackground(new java.awt.Color(255, 255, 255));
        panelRounded1.setRoundBottomLeft(25);
        panelRounded1.setRoundBottomRight(25);
        panelRounded1.setRoundTopLeft(25);
        panelRounded1.setRoundTopRight(25);

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("REGISTER TENANT");

        FULLNAME.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        FULLNAME.setLabelText("ENTER FULLNAME");
        FULLNAME.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FULLNAMEActionPerformed(evt);
            }
        });
        FULLNAME.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                FULLNAMEKeyTyped(evt);
            }
        });

        AGE.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        AGE.setLabelText("ENTER AGE");
        AGE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AGEActionPerformed(evt);
            }
        });
        AGE.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                AGEKeyTyped(evt);
            }
        });

        buttonGroup1.add(FEMALE);
        FEMALE.setText("FEMALE");
        FEMALE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FEMALEActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 153, 153));
        jLabel2.setText("GENDER");

        buttonGroup1.add(MALE);
        MALE.setText("MALE");
        MALE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MALEActionPerformed(evt);
            }
        });

        PHONENUMBER.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        PHONENUMBER.setLabelText("ENTER PHONE NUMBER");
        PHONENUMBER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PHONENUMBERActionPerformed(evt);
            }
        });
        PHONENUMBER.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                PHONENUMBERKeyTyped(evt);
            }
        });

        ROOMCATEGORY.setBackground(new java.awt.Color(102, 102, 102));
        ROOMCATEGORY.setForeground(new java.awt.Color(255, 255, 255));
        ROOMCATEGORY.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        ROOMCATEGORY.setLabeText("ROOM CATEGORY");
        ROOMCATEGORY.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ROOMCATEGORYActionPerformed(evt);
            }
        });

        ADDRESS.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        ADDRESS.setLabelText("ENTER ADDRESS");
        ADDRESS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ADDRESSActionPerformed(evt);
            }
        });

        ADD.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        ADD.setText("REGISTER TENANT");
        ADD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ADDActionPerformed(evt);
            }
        });

        UPDATE.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        UPDATE.setText("UPDATE");
        UPDATE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPDATEActionPerformed(evt);
            }
        });

        DISABLE_USER.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        DISABLE_USER.setText("DISABLE");
        DISABLE_USER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DISABLE_USERActionPerformed(evt);
            }
        });

        SEARCHFULLNAME.setLabelText("SEARCH NAME");
        SEARCHFULLNAME.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                SEARCHFULLNAMEKeyReleased(evt);
            }
        });

        ROOMRATE.setEditable(false);
        ROOMRATE.setBackground(new java.awt.Color(255, 255, 255));
        ROOMRATE.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 14)); // NOI18N
        ROOMRATE.setLabelText("ROOM RATE");
        ROOMRATE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ROOMRATEActionPerformed(evt);
            }
        });
        ROOMRATE.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ROOMRATEKeyTyped(evt);
            }
        });

        DATE.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        DATE.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 153), 1, true));

        DELETE1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        DELETE1.setText("DELETE TENANT");
        DELETE1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DELETE1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelRounded1Layout = new javax.swing.GroupLayout(panelRounded1);
        panelRounded1.setLayout(panelRounded1Layout);
        panelRounded1Layout.setHorizontalGroup(
            panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRounded1Layout.createSequentialGroup()
                .addGroup(panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelRounded1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelRounded1Layout.createSequentialGroup()
                                .addGroup(panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelRounded1Layout.createSequentialGroup()
                                        .addComponent(FULLNAME, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(AGE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(PHONENUMBER, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelRounded1Layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addGap(10, 10, 10)
                                        .addComponent(MALE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(FEMALE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 76, Short.MAX_VALUE)
                                        .addComponent(ROOMRATE, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(ROOMCATEGORY, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(ADDRESS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(panelRounded1Layout.createSequentialGroup()
                                .addComponent(ADD, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(UPDATE, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(DISABLE_USER, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(DELETE1, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(DATE, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(panelRounded1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelRounded1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jSeparator1))
                        .addGap(18, 18, 18)
                        .addComponent(SEARCHFULLNAME, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)))
                .addGap(18, 18, 18))
        );
        panelRounded1Layout.setVerticalGroup(
            panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRounded1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelRounded1Layout.createSequentialGroup()
                        .addGroup(panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(SEARCHFULLNAME, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(panelRounded1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 5, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(FULLNAME, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(AGE, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(FEMALE, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(MALE, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ROOMCATEGORY, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(ROOMRATE, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PHONENUMBER, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelRounded1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(ADDRESS, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelRounded1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ADD, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(UPDATE, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(DISABLE_USER, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(DELETE1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(DATE, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28))
        );

        SHOW_OCCUPANT_TBL.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "DATE", "TENANTS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        SHOW_OCCUPANT_TBL.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(SHOW_OCCUPANT_TBL);
        if (SHOW_OCCUPANT_TBL.getColumnModel().getColumnCount() > 0) {
            SHOW_OCCUPANT_TBL.getColumnModel().getColumn(0).setPreferredWidth(12);
        }

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelRounded1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 985, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addComponent(jScrollPane2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelRounded1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout form1Layout = new javax.swing.GroupLayout(form1);
        form1.setLayout(form1Layout);
        form1Layout.setHorizontalGroup(
            form1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1308, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        form1Layout.setVerticalGroup(
            form1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 783, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(form1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(form1, javax.swing.GroupLayout.DEFAULT_SIZE, 783, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void FULLNAMEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FULLNAMEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FULLNAMEActionPerformed

    private void AGEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AGEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AGEActionPerformed

    private void FEMALEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FEMALEActionPerformed
        GENDER();
    }//GEN-LAST:event_FEMALEActionPerformed

    private void MALEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MALEActionPerformed
       GENDER();
    }//GEN-LAST:event_MALEActionPerformed

    private void PHONENUMBERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PHONENUMBERActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PHONENUMBERActionPerformed

    private void ADDRESSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ADDRESSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ADDRESSActionPerformed

    private void ADDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ADDActionPerformed
      REGISTER_TENANT();
    }//GEN-LAST:event_ADDActionPerformed

    private void UPDATEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPDATEActionPerformed
    UPDATE_TENANT_INFORMATION();
    }//GEN-LAST:event_UPDATEActionPerformed

    private void DISABLE_USERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DISABLE_USERActionPerformed
        DISABLE_UPDATE_CHECK_NAME();
    }//GEN-LAST:event_DISABLE_USERActionPerformed

    private void PHONENUMBERKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PHONENUMBERKeyTyped
        // TODO add your handling code here:
        char vchar = evt.getKeyChar();
        if(!(Character.isDigit(vchar))){
            evt.consume();
        }
    }//GEN-LAST:event_PHONENUMBERKeyTyped

    private void AGEKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_AGEKeyTyped
        // TODO add your handling code here:
        char vchar = evt.getKeyChar();
        if(!(Character.isDigit(vchar))){
            evt.consume();
        }
    }//GEN-LAST:event_AGEKeyTyped

    private void FULLNAMEKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_FULLNAMEKeyTyped
        // TODO add your handling code here:
        
    }//GEN-LAST:event_FULLNAMEKeyTyped

    private void ROOMRATEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ROOMRATEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ROOMRATEActionPerformed

    private void ROOMRATEKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ROOMRATEKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_ROOMRATEKeyTyped

    private void DELETE1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DELETE1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DELETE1ActionPerformed

    private void ROOMCATEGORYActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ROOMCATEGORYActionPerformed
        ROOMRATE.setText("");
        room_RATE();
        CATEGORY_DBTN.setText("");
        DefaultTableModel dsf= (DefaultTableModel)SHOW_OCCUPANT_TBL.getModel();
        dsf.setRowCount(0);
        DATABASE_TBL_STORE_TENANTS();
    }//GEN-LAST:event_ROOMCATEGORYActionPerformed

    private void MANAGETENANT_TBLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MANAGETENANT_TBLMouseClicked
        SHOW_TENANT_INF0_FROM_TBL();
    }//GEN-LAST:event_MANAGETENANT_TBLMouseClicked

    private void SEARCHFULLNAMEKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SEARCHFULLNAMEKeyReleased
        DefaultTableModel dtm =(DefaultTableModel)MANAGETENANT_TBL.getModel();
        String search = SEARCHFULLNAME.getText();
        TableRowSorter<DefaultTableModel> srs = new TableRowSorter<DefaultTableModel>(dtm);
        MANAGETENANT_TBL.setRowSorter(srs);
        srs.setRowFilter(RowFilter.regexFilter(search));
    }//GEN-LAST:event_SEARCHFULLNAMEKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.raven.swing.Button ADD;
    private textfield.TextField ADDRESS;
    private textfield.TextField AGE;
    private javax.swing.JLabel CATEGORY_DBTN;
    private javax.swing.JLabel DATE;
    private com.raven.swing.Button DELETE1;
    private com.raven.swing.Button DISABLE_USER;
    private javax.swing.JLabel DUEDATE;
    private radio_button.RadioButtonCustom FEMALE;
    private textfield.TextField FULLNAME;
    private javax.swing.JLabel GENDER;
    private javax.swing.JLabel GETROOMCATEGORY;
    private radio_button.RadioButtonCustom MALE;
    private tabledark.TableDark MANAGETENANT_TBL;
    private javax.swing.JLabel MAX;
    private javax.swing.JLabel MIN;
    private textfield.TextField PHONENUMBER;
    private combobox.Combobox ROOMCATEGORY;
    private textfield.TextField ROOMRATE;
    private textfield.TextField SEARCHFULLNAME;
    private tabledark.TableDark SHOW_OCCUPANT_TBL;
    private javax.swing.JLabel TOTAL;
    private com.raven.swing.Button UPDATE;
    private javax.swing.ButtonGroup buttonGroup1;
    private compo.Form form1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private ROUNDEDPANEL.PanelRounded panelRounded1;
    // End of variables declaration//GEN-END:variables
    
    
    private void clearselection(){
        FULLNAME.setText("");
        AGE.setText("");
        GENDER.setText("");
        PHONENUMBER.setText("");
        ADDRESS.setText("");
        ROOMRATE.setText("");
        ROOMCATEGORY.setSelectedItem(null);
    }
    
    private void SHOW_DATE_TIME(){
        Date thisDate = new Date();SimpleDateFormat dateForm = new SimpleDateFormat("MMMM/dd/YY");
        DATE.setText(dateForm.format(thisDate));
    }
    
    private void GENDER(){
            if(MALE.isSelected()){
            GENDER.setText("MALE");
            }if(FEMALE.isSelected()){
            GENDER.setText("FEMALE");
            }
        }
    
    private void GENDER_SELECTED_FROM_TABLE(){
        int i = MANAGETENANT_TBL.getSelectedRow();
        TableModel model = MANAGETENANT_TBL.getModel();
        FULLNAME.setText(model.getValueAt(i, 0).toString());
        AGE.setText(model.getValueAt(i, 1).toString());
        GENDER.setText(model.getValueAt(i, 2).toString());
        PHONENUMBER.setText(model.getValueAt(i, 3).toString());
        ADDRESS.setText(model.getValueAt(i, 4).toString());
        ROOMCATEGORY.setSelectedItem(model.getValueAt(i, 5).toString());
        ROOMRATE.setText(model.getValueAt(i, 7).toString());
        if(GENDER.equals("MALE")){
            MALE.isSelected();
            }if(GENDER.equals("FEMALE")){
            FEMALE.isSelected();
            }
    }
    
    
    
    private void FETCH_TENANT_INFO(){
        try {
            int q;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            pstmt = conn.prepareStatement("SELECT * FROM tenant_tbl");
            rs = pstmt.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q=rss.getColumnCount();
            DefaultTableModel df= (DefaultTableModel)MANAGETENANT_TBL.getModel();
            df.setRowCount(0);
            while(rs.next()){
            Vector v2 = new Vector();
            for(int a=1; a<=q;a++){
        
            v2.add(rs.getString("fullname"));
            v2.add(rs.getString("age"));
            v2.add(rs.getString("gender"));
            v2.add(rs.getString("phonenumber"));
            v2.add(rs.getString("address"));
            v2.add(rs.getString("room_category"));
            v2.add(rs.getString("room_rate"));
            }
            df.addRow(v2);
            
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    private void REGISTER_TENANT(){
        String fullname = FULLNAME.getText().trim();
        String age = AGE.getText().trim();
        String gender = GENDER.getText().trim();
        String phonenumber = PHONENUMBER.getText().trim();
        String address = ADDRESS.getText().trim();
        String getrr = ROOMRATE.getText();
        String getRC = (String) ROOMCATEGORY.getSelectedItem();
        String cdbtn = CATEGORY_DBTN.getText();
        if (!fullname.isEmpty() && !age.isEmpty() && !gender.isEmpty() && !phonenumber.isEmpty() && !address.isEmpty() && !getrr.isEmpty() && getRC != null ){
        
        try {
        
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
        String sql = "SELECT * FROM tenant_tbl WHERE fullname=?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, fullname);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            int option = JOptionPane.showConfirmDialog(rootPane,"NAME ALREADY REGISTERED.OR WOULD YOU LIKE TO RE-ASSIGN TENANT ROOM CATEGORY? ", "CONFIRM", JOptionPane.YES_NO_OPTION);
            if (option == YES_OPTION) {
                MAX_OCCUPI();
            }
            
            clearselection();
        } else {
        
        MAX_OCCUPI();
      
   }
} catch (SQLException e) {
   // Handle any SQL errors
} finally {
   // Close the ResultSet, PreparedStatement, and Connection
   if (rs != null) {
       try {
           rs.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
   if (pstmt != null) {
       try {
           pstmt.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
   if (conn != null) {
       try {
           conn.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
} 
        
        
        }else{
            JOptionPane.showMessageDialog(this,"FILL ALL THE BLANKS.");
            
        }
        
    }
    
    
    
    
    private void MAX_OCCUPI(){
        String getRC = (String) ROOMCATEGORY.getSelectedItem();
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            String sql = "SELECT * FROM room_tbl WHERE room_category=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, getRC);
            rs = pstmt.executeQuery();
            if(rs.next()){
            
                MIN.setText("");
                TOTAL.setText("");
                String max = rs.getString("room_capacity");
                String tennum = rs.getString("num_occupants");
                
                
                MIN.setText(tennum);
                if(tennum.equals(max)){
                JOptionPane.showMessageDialog(this,"THE ROOM IS ALREADY FULL, FIND ANOTHER ONE.");
                }else{  
                double numberget = Double.parseDouble(MIN.getText());
                double sum = numberget + 1;   
                TOTAL.setText(String.format("%.0f",sum));
                String gettotal = TOTAL.getText();
                        
                
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
                String sqll = "UPDATE room_tbl SET num_occupants='" + gettotal + "' WHERE room_category='" + getRC + "'";
                stmt = conn.createStatement();
                stmt.execute(sqll);
                MIN.setText("");
                TOTAL.setText("");
                ADD_TENANT();
                      
            }
            }else{
                JOptionPane.showMessageDialog(this,"ERROR...");
            }
        } catch (SQLException ex) {
            Logger.getLogger(MANAGETENANT.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
    private void ADD_TENANT(){
        String fullname = FULLNAME.getText().trim();
        String age = AGE.getText().trim();
        String gender = GENDER.getText().trim();
        String phonenumber = PHONENUMBER.getText().trim();
        String address = ADDRESS.getText().trim();
        String getRC = (String) ROOMCATEGORY.getSelectedItem();
        String getrr = ROOMRATE.getText();
        String getdate = DATE.getText();
        String cdbtn = CATEGORY_DBTN.getText();
        int option = JOptionPane.showConfirmDialog(rootPane,"TENANT NAME CAN'T BE UPDATED LATER ON AS IT USED AS IDEINTIFIER. REGISTER TENANT?", "CONFIRM", JOptionPane.YES_NO_OPTION);
            if (option == YES_OPTION) {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            String sql = "INSERT INTO tenant_tbl (fullname, age, gender, phonenumber, address, room_category, room_rate,category_db) VALUES ('"+fullname+"','"+age+"','"+gender+"','"+phonenumber+"','"+address+"','"+getRC+"','"+getrr+"','"+cdbtn+"')";
            pstmt = conn.prepareStatement(sql);
            pstmt.executeUpdate();
            
            JOptionPane.showMessageDialog(this,"USER BEEN REGISTERED.");
            CHECK_ROOM_TBL();
            FETCH_TENANT_INFO();
        } catch (SQLException ex) {
            Logger.getLogger(MANAGETENANT.class.getName()).log(Level.SEVERE, null, ex);
        }
            }else{
            exit();
            }
    
    }
    
    private void CHECK_ROOM_TBL(){
        try { 
            String fullname = FULLNAME.getText().trim();
            String getdate = DATE.getText();
            String getRC = (String) ROOMCATEGORY.getSelectedItem();
            String cdbtn = CATEGORY_DBTN.getText();
            DUEDATE.setText("");
            Date thisDate = new Date(); 
            Calendar cal = Calendar.getInstance();
            cal.setTime(thisDate);
            cal.add(Calendar.DATE, 30);
            Date newDate = cal.getTime();
            SimpleDateFormat dateForm = new SimpleDateFormat("MMMM/dd/YY");
            DUEDATE.setText(dateForm.format(newDate));
            String getduedate = DUEDATE.getText();
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            String sqll = "INSERT INTO "+cdbtn+" (date_started, due_date, name) VALUES ('"+getdate+"', '"+getduedate+"', '"+fullname+"')";
            pstmt = conn.prepareStatement(sqll);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this,"TENANT "+fullname+" ASSIGNED TO "+getRC+".");
            clearselection();
        } catch (SQLException ex) {
            Logger.getLogger(MANAGETENANT.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
    public void room_ID(){
        
    try {
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
        String sql= "SELECT * FROM room_tbl";
        pstmt =conn.prepareStatement(sql);
        rs = pstmt.executeQuery(sql);
        while(rs.next()){
        String room = rs.getString("room_category");
        ROOMCATEGORY.addItem(room);
        ROOMCATEGORY.setSelectedItem(null);
        
        }
    } catch (SQLException ex) {
        Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
    } catch (ClassNotFoundException ex) {
        Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
    }
    }
    
    public void room_RATE(){
        
    try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            String sql = "SELECT * FROM room_tbl WHERE room_category=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, (String) ROOMCATEGORY.getSelectedItem());
            ResultSet rs= pst.executeQuery();
            if(rs.next()){
                String roomrate = rs.getString("room_rate");
                ROOMRATE.setText(roomrate);
                
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void DATABASE_TBL_STORE_TENANTS(){
        
    try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            String sql = "SELECT * FROM room_tbl WHERE room_category=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, (String) ROOMCATEGORY.getSelectedItem());
            ResultSet rs= pst.executeQuery();
            if(rs.next()){
                String CATG = rs.getString("category_dbtn");
                CATEGORY_DBTN.setText(CATG);
                int q;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            pstmt = conn.prepareStatement("SELECT * FROM "+CATG+"");
            rs = pstmt.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            q=rss.getColumnCount();
            DefaultTableModel df= (DefaultTableModel)SHOW_OCCUPANT_TBL.getModel();
            df.setRowCount(0);
            while(rs.next()){
            Vector v2 = new Vector();
            for(int a=1; a<=q;a++){
            v2.add(rs.getString("date_started"));    
            v2.add(rs.getString("name"));
            }
            df.addRow(v2);
            
            }
            
            }
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void SHOW_TENANT_INF0_FROM_TBL(){
        GETROOMCATEGORY.setText("");
        int i = MANAGETENANT_TBL.getSelectedRow();
        TableModel model = MANAGETENANT_TBL.getModel();
        FULLNAME.setText(model.getValueAt(i, 0).toString());
        AGE.setText(model.getValueAt(i, 1).toString());
        GENDER.setText(model.getValueAt(i, 2).toString());
        PHONENUMBER.setText(model.getValueAt(i, 3).toString());
        ADDRESS.setText(model.getValueAt(i, 4).toString());
        ROOMCATEGORY.setSelectedItem(model.getValueAt(i, 5).toString());
        GETROOMCATEGORY.setText(model.getValueAt(i, 5).toString());
        ROOMRATE.setText(model.getValueAt(i, 6).toString());
        
        
    }


    
    
    private void DISABLE_UPDATE_CHECK_NAME(){
        
        String fullname = FULLNAME.getText().trim();
        String age = AGE.getText().trim();
        String gender = GENDER.getText().trim();
        String phonenumber = PHONENUMBER.getText().trim();
        String address = ADDRESS.getText().trim();
        String getrr = ROOMRATE.getText();
        String getRC = (String) ROOMCATEGORY.getSelectedItem();
        String cdbtn = CATEGORY_DBTN.getText();
        if (!fullname.isEmpty() && !age.isEmpty() && !gender.isEmpty() && !phonenumber.isEmpty() && !address.isEmpty() && !getrr.isEmpty() && getRC != null ){
        
        try {
        
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
        String sql = "SELECT * FROM tenant_tbl WHERE fullname=?";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, fullname);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            String sqlll = "SELECT * FROM tenant_tbl WHERE category_db=?";
            pstmt = conn.prepareStatement(sqlll);
            pstmt.setString(1, cdbtn);
            rs = pstmt.executeQuery();
            if(rs.next()){
                //JOptionPane.showMessageDialog(this,"SA");
                DECREMENT_OCCUPI();
            }else{
            JOptionPane.showMessageDialog(this,"TABLE NAME CATEGORY NOT FOUND.");
            }
            
        } else {
        
        JOptionPane.showMessageDialog(this,"NAME NOT FOUND.");
      
   }
} catch (SQLException e) {
   // Handle any SQL errors
} finally {
   // Close the ResultSet, PreparedStatement, and Connection
   if (rs != null) {
       try {
           rs.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
   if (pstmt != null) {
       try {
           pstmt.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
   if (conn != null) {
       try {
           conn.close();
       } catch (SQLException ex) {
           Logger.getLogger(Menu3.class.getName()).log(Level.SEVERE, null, ex);
       }
   }
} 
        
        
        }else{
            JOptionPane.showMessageDialog(this,"FILL ALL THE BLANKS.");
            
        }
    
    }
    
    private void DECREMENT_OCCUPI(){
        String decre =GETROOMCATEGORY.getText();
        String getRC = (String) ROOMCATEGORY.getSelectedItem();
        String disablerrrc = "";
        String fullname = FULLNAME.getText().trim();
        String cdbtn = CATEGORY_DBTN.getText();  
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
            String sql = "SELECT * FROM room_tbl WHERE room_category=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, decre);
            rs = pstmt.executeQuery();
            
            if(rs.next()){
            
                MIN.setText("");
                TOTAL.setText("");
                String max = rs.getString("room_capacity");
                String tennum = rs.getString("num_occupants");
                MIN.setText(tennum);
                double numberget = Double.parseDouble(MIN.getText());
                double sum = numberget - 1;   
                TOTAL.setText(String.format("%.0f",sum));
                String gettotal = TOTAL.getText();
                
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
                String sqll = "UPDATE room_tbl SET num_occupants='" + gettotal + "' WHERE room_category='" + decre + "'";
                stmt = conn.createStatement();
                stmt.execute(sqll);
                MIN.setText("");
                TOTAL.setText("");
                
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
                String sqllll = "DELETE FROM "+cdbtn+" WHERE name ='"+ fullname +"'";
                stmt = conn.createStatement();
                stmt.execute(sqllll);

            
                
                String sqlll = "UPDATE tenant_tbl SET room_category='" + disablerrrc + "', room_rate='" + disablerrrc + "', category_db='" + disablerrrc + "' WHERE fullname='" + fullname + "'";
                stmt = conn.createStatement();
                stmt.execute(sqlll);
                
                JOptionPane.showMessageDialog(this,"ACCOUNT DISABLED.");
                
  
            }else{
                JOptionPane.showMessageDialog(this,"ROOM CATEGORY NOT FOUND...");
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(MANAGETENANT.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
   
    
    
    
    private void UPDATE_TENANT_INFORMATION(){
        String getrr = ROOMRATE.getText();
        String getRC = (String) ROOMCATEGORY.getSelectedItem();
        String cdbtn = CATEGORY_DBTN.getText();
        String disablerrrc = "";
        
        String fullname = FULLNAME.getText().trim();
        String age = AGE.getText().trim();
        String gender = GENDER.getText().trim();
        String phonenumber = PHONENUMBER.getText().trim();
        String address = ADDRESS.getText().trim();
        if (!fullname.isEmpty() && !age.isEmpty() && !gender.isEmpty() && !phonenumber.isEmpty() && !address.isEmpty()){
        if (!getrr.equals(disablerrrc)){
            JOptionPane.showMessageDialog(this,"ACCOUNT MUST BE DISABLED.");
        
        }else{
            int option = JOptionPane.showConfirmDialog(rootPane,"TENANT FULLNAME IS USED AS TABLE IDENTIFIER AND THIS WILL BE EXCLUDED FROM THIS UPDATE.UPDATE TENANT INFORMATION?", "CONFIRM", JOptionPane.YES_NO_OPTION);
            if (option == YES_OPTION) {
            
                try {
                    
                    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mini_system", "root", "");
                    String sqll = "UPDATE tenant_tbl SET age='" + age + "', gender='" + gender + "', phonenumber='" + phonenumber + "', address='" + address + "' WHERE fullname='" + fullname + "'";
                    stmt = conn.createStatement();
                    stmt.execute(sqll);
                    JOptionPane.showMessageDialog(this,"PERSONAL INFO BEEN UPDATED.");
                    
                    FETCH_TENANT_INFO();
                } catch (SQLException ex) {
                    Logger.getLogger(MANAGETENANT.class.getName()).log(Level.SEVERE, null, ex);
                }
            }else{
            exit();
            }
    }
        }else{JOptionPane.showMessageDialog(this,"FILL ALL TENANT INFORMATION.");}
   }
    
}
    
    
    
    
     
    
    
    
    


