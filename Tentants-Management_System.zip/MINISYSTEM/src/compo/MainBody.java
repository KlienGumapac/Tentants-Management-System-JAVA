package compo;

import com.raven.swing.scrollbar.ScrollBarCustom;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JScrollPane;

public class MainBody extends javax.swing.JPanel {

    public MainBody() {
        initComponents();
        setOpaque(false);
        scroll.setBorder(null);
        scroll.setViewportBorder(null);
        scroll.getViewport().setOpaque(false);
        scroll.setVerticalScrollBar(new ScrollBarCustom());
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    }

    public void displayForm(Component form) {
        displayForm(form, "");
    }

    public void displayForm(Component form, String title) {
        
        panelBody.removeAll();
        panelBody.add(form);
        panelBody.repaint();
        panelBody.revalidate();
    }

    public void changeColor(Color color) {
        
        if (panelBody.getComponentCount() != 0) {
            Form com = (Form) panelBody.getComponent(0);
            com.changeColor(color);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        scroll = new javax.swing.JScrollPane();
        panelBody = new javax.swing.JPanel();

        panelBody.setOpaque(false);
        panelBody.setLayout(new java.awt.BorderLayout());
        scroll.setViewportView(panelBody);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scroll, javax.swing.GroupLayout.DEFAULT_SIZE, 877, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scroll, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 489, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel panelBody;
    private javax.swing.JScrollPane scroll;
    // End of variables declaration//GEN-END:variables
}
