package com.raven.swing;

public interface EventSwitchSelected {

    public void onSelected(boolean selected);
}
