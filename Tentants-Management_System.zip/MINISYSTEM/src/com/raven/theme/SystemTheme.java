package com.raven.theme;

import java.awt.Color;

public class SystemTheme {

    //  Default theme color
    public static Color mainColor = new Color(54, 149, 255);
}
