-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2023 at 02:51 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mini_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `cdtnr2f4um`
--

CREATE TABLE `cdtnr2f4um` (
  `id` int(11) NOT NULL,
  `date` int(255) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cdtnr2f4um`
--

INSERT INTO `cdtnr2f4um` (`id`, `date`, `name`) VALUES
(1, 0, 'ANGEL ERIC L. VALENCIA');

-- --------------------------------------------------------

--
-- Table structure for table `room_tbl`
--

CREATE TABLE `room_tbl` (
  `id` int(255) NOT NULL,
  `room_category` varchar(255) NOT NULL,
  `room_rent` int(255) NOT NULL,
  `water_bill` int(255) NOT NULL,
  `electric_bill` int(255) NOT NULL,
  `room_rate` int(11) NOT NULL,
  `room_capacity` int(255) NOT NULL,
  `num_occupants` int(255) NOT NULL,
  `category_dbtn` varchar(255) NOT NULL,
  `payment_dbtn` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room_tbl`
--

INSERT INTO `room_tbl` (`id`, `room_category`, `room_rent`, `water_bill`, `electric_bill`, `room_rate`, `room_capacity`, `num_occupants`, `category_dbtn`, `payment_dbtn`) VALUES
(20, 'ROOM2 FOR 4 USERS MALE', 900, 900, 900, 2700, 4, 0, 'cdtnr2f4um', 'pdtnr2f4um');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(255) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `age` int(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `phone_number` int(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `current_room` varchar(255) NOT NULL,
  `room_rate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `unique_id`, `full_name`, `age`, `gender`, `phone_number`, `address`, `current_room`, `room_rate`) VALUES
(21, 'USER-UID2', 'ANGEL ERIC L. VALENCIA THE GWAPO', 19, 'Male', 987612345, 'UK', 'DISABLED', 'DISABLED'),
(22, 'USER-UID1', 'ERIC', 19, 'Male', 909090909, 'GERMANY', 'VIP', '10000');

-- --------------------------------------------------------

--
-- Table structure for table `user_id_creation_tbl`
--

CREATE TABLE `user_id_creation_tbl` (
  `id` int(255) NOT NULL,
  `unique_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_id_creation_tbl`
--

INSERT INTO `user_id_creation_tbl` (`id`, `unique_id`) VALUES
(1, 'USER-UID1'),
(2, 'USER-UID2'),
(3, 'USER-UID3'),
(4, 'USER-UID4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cdtnr2f4um`
--
ALTER TABLE `cdtnr2f4um`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room_tbl`
--
ALTER TABLE `room_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_id_creation_tbl`
--
ALTER TABLE `user_id_creation_tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cdtnr2f4um`
--
ALTER TABLE `cdtnr2f4um`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `room_tbl`
--
ALTER TABLE `room_tbl`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user_id_creation_tbl`
--
ALTER TABLE `user_id_creation_tbl`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
