-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2023 at 03:12 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mini_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `rctnr1f4um`
--

CREATE TABLE `rctnr1f4um` (
  `id` int(11) NOT NULL,
  `date` text NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rctnr1f4um`
--

INSERT INTO `rctnr1f4um` (`id`, `date`, `name`) VALUES
(1, 'January /11/23', 'ANGEL ERIC L. VALENCIA');

-- --------------------------------------------------------

--
-- Table structure for table `rctnr2f4um`
--

CREATE TABLE `rctnr2f4um` (
  `id` int(11) NOT NULL,
  `date` text NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `room_tbl`
--

CREATE TABLE `room_tbl` (
  `id` int(255) NOT NULL,
  `room_category` varchar(255) NOT NULL,
  `room_rent` int(255) NOT NULL,
  `water_bill` int(255) NOT NULL,
  `electric_bill` int(255) NOT NULL,
  `room_rate` int(11) NOT NULL,
  `room_capacity` int(255) NOT NULL,
  `num_occupants` int(255) NOT NULL,
  `category_dbtn` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room_tbl`
--

INSERT INTO `room_tbl` (`id`, `room_category`, `room_rent`, `water_bill`, `electric_bill`, `room_rate`, `room_capacity`, `num_occupants`, `category_dbtn`) VALUES
(33, 'ROOM1 FOR 4 USERS MALE', 900, 900, 900, 2700, 4, 1, 'rctnr1f4um'),
(34, 'ROOM2 FOR 4 USERS MALE', 900, 900, 900, 2700, 4, 1, 'rctnr2f4um');

-- --------------------------------------------------------

--
-- Table structure for table `tenant_tbl`
--

CREATE TABLE `tenant_tbl` (
  `id` int(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `age` int(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `phonenumber` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `room_category` varchar(255) NOT NULL,
  `room_rate` varchar(255) NOT NULL,
  `category_db` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tenant_tbl`
--

INSERT INTO `tenant_tbl` (`id`, `fullname`, `age`, `gender`, `phonenumber`, `address`, `room_category`, `room_rate`, `category_db`) VALUES
(24, 'ANGEL ERIC L. VALENCIA', 19, 'MALE', '09751324212', 'GERMANY', 'ROOM1 FOR 4 USERS MALE', '2700', 'rctnr1f4um');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rctnr1f4um`
--
ALTER TABLE `rctnr1f4um`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rctnr2f4um`
--
ALTER TABLE `rctnr2f4um`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room_tbl`
--
ALTER TABLE `room_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tenant_tbl`
--
ALTER TABLE `tenant_tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rctnr1f4um`
--
ALTER TABLE `rctnr1f4um`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rctnr2f4um`
--
ALTER TABLE `rctnr2f4um`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `room_tbl`
--
ALTER TABLE `room_tbl`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `tenant_tbl`
--
ALTER TABLE `tenant_tbl`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
